var obj = require("../config/db_properties");
var mongodb = require("mongodb");
var express = require("express");
var router = express.Router();
var nareshIT = mongodb.MongoClient;
router.post("/",(req,res)=>{
    var token = req.body.token;
    if(token == obj.token){
        nareshIT.connect("mongodb://localhost:27017/poc",(err,db)=>{
            db.collection("contact").find().toArray((err,array)=>{
                res.send(array);
            });
        });
    }else{
        res.send("UnAuthorized User...!");
    }
});
module.exports = router;