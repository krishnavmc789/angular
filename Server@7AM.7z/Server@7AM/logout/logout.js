var obj = require("../config/db_properties");
var express = require("express");
var router = express.Router();
router.post("/",(req,res)=>{
    var token = req.body.token;
    if(token == obj.token){
        obj.token = "";
        res.send({"logout":"success"});
    }else{
        res.send({"logout":"fail"});
    }
});
module.exports = router;