module.exports = {
    host    :   "localhost",
    user    :   "root",
    password:   "root",
    database:   "poc",
    token   :   ""
};