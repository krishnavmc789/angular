//import db_properties
//we will store server token here
var obj = require("../config/db_properties");
//import db_connection
var conn = require("../config/db_connection");
//get the connection object
var connection = conn.getConnection();
//connect to database
connection.connect(); 
//import function
var my_fun = require("../token/token");
//import express module
var express = require("express");
//create router instance
var router = express.Router();
//create the Rest API
router.post("/",(req,res)=>{
    var uname = req.body.uname;
    var upwd = req.body.upwd;
    connection.query("select * from login_details where uname='"+uname+"' and upwd='"+upwd+"'",
                (err,recordsArray,fields)=>{
        if(recordsArray.length>0){
            var token = my_fun("Hello","12345ABCDEF")
            obj.token = token;
            res.send({"login":"success","token":token});
        }else{
            res.send({"login":"fail"});
        }
    });
});
module.exports = router;