//import express module
var express = require("express");
//import body-parser module
var bodyparser = require("body-parser");
//import cors module
var cors = require("cors");
//create the Rest Object
var app = express();
//enable cors
app.use(cors());
//set the JSON As MIME Type
app.use(bodyparser.json());
//parse the JSON
app.use(bodyparser.urlencoded({extended:false}));
//import login module
var module1 = require("./login/login");
app.use("/login",module1);
//import about module
var module2 = require("./about/about");
app.use("/about",module2);
//import contact module
var module3 = require("./contact/contact");
app.use("/contact",module3);
//import portfolio module
var module4 = require("./portfolio/portfolio");
app.use("/portfolio",module4);
//import logout module
var module5 = require("./logout/logout");
app.use("/logout",module5);
//assign the port no.
app.listen(8080);
console.log("Server Listening the port no.8080");