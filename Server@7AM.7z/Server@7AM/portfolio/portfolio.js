var express = require("express");
var mssql = require("mssql");
var router = express.Router();
router.post("/",(req,res)=>{
    //connect to sql server
    mssql.connect({
        server  :   "localhost",
        user    :   "sa",
        password:   "123",
        database:   "poc" 
    },(err)=>{
        if(err){
            console.log("Connection Refused !!!");
        }else{
            var request = new mssql.Request();
            request.query("select * from portfolio",
                                                (err,records)=>{
                res.send(records);
                mssql.close();
            });
        }
    });
});
module.exports = router;