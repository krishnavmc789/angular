//import db_properties
var obj = require("../config/db_properties");
//import db_connection
var conn = require("../config/db_connection");
//get the connection object
var connection = conn.getConnection();
//connect to database
connection.connect();
//import express module
var express = require("express");
//create the router instance
var router = express.Router();
//create the Rest API
router.post("/",(req,res)=>{
    var token = req.body.token;
    if( token == obj.token ){
        connection.query("select * from about",(err,recordsArray,fields)=>{
            res.send(recordsArray);
        });
    }else{
        res.send("UnAuthrozed User...!");
    }
});
//export the router
module.exports = router;